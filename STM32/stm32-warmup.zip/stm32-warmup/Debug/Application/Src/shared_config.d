Application/Src/shared_config.o: ../Application/Src/shared_config.c \
 ../Application/Inc/shared_config.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 ../Application/Inc/project_config.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h
../Application/Inc/shared_config.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
../Application/Inc/project_config.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
