################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/Src/alarm_event.c \
../Application/Src/app_init.c \
../Application/Src/log_queue.c \
../Application/Src/shared_config.c \
../Application/Src/task_display.c \
../Application/Src/task_filter.c \
../Application/Src/task_logger.c \
../Application/Src/task_sensor.c \
../Application/Src/task_stats.c \
../Application/Src/usb_serial.c 

OBJS += \
./Application/Src/alarm_event.o \
./Application/Src/app_init.o \
./Application/Src/log_queue.o \
./Application/Src/shared_config.o \
./Application/Src/task_display.o \
./Application/Src/task_filter.o \
./Application/Src/task_logger.o \
./Application/Src/task_sensor.o \
./Application/Src/task_stats.o \
./Application/Src/usb_serial.o 

C_DEPS += \
./Application/Src/alarm_event.d \
./Application/Src/app_init.d \
./Application/Src/log_queue.d \
./Application/Src/shared_config.d \
./Application/Src/task_display.d \
./Application/Src/task_filter.d \
./Application/Src/task_logger.d \
./Application/Src/task_sensor.d \
./Application/Src/task_stats.d \
./Application/Src/usb_serial.d 


# Each subdirectory must supply rules for building sources it contributes
Application/Src/%.o Application/Src/%.su Application/Src/%.cyclo: ../Application/Src/%.c Application/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Application/Inc -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Application-2f-Src

clean-Application-2f-Src:
	-$(RM) ./Application/Src/alarm_event.cyclo ./Application/Src/alarm_event.d ./Application/Src/alarm_event.o ./Application/Src/alarm_event.su ./Application/Src/app_init.cyclo ./Application/Src/app_init.d ./Application/Src/app_init.o ./Application/Src/app_init.su ./Application/Src/log_queue.cyclo ./Application/Src/log_queue.d ./Application/Src/log_queue.o ./Application/Src/log_queue.su ./Application/Src/shared_config.cyclo ./Application/Src/shared_config.d ./Application/Src/shared_config.o ./Application/Src/shared_config.su ./Application/Src/task_display.cyclo ./Application/Src/task_display.d ./Application/Src/task_display.o ./Application/Src/task_display.su ./Application/Src/task_filter.cyclo ./Application/Src/task_filter.d ./Application/Src/task_filter.o ./Application/Src/task_filter.su ./Application/Src/task_logger.cyclo ./Application/Src/task_logger.d ./Application/Src/task_logger.o ./Application/Src/task_logger.su ./Application/Src/task_sensor.cyclo ./Application/Src/task_sensor.d ./Application/Src/task_sensor.o ./Application/Src/task_sensor.su ./Application/Src/task_stats.cyclo ./Application/Src/task_stats.d ./Application/Src/task_stats.o ./Application/Src/task_stats.su ./Application/Src/usb_serial.cyclo ./Application/Src/usb_serial.d ./Application/Src/usb_serial.o ./Application/Src/usb_serial.su

.PHONY: clean-Application-2f-Src

